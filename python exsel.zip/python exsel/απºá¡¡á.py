from asyncore import read
from email.mime import image
from lib2to3.pgen2 import driver
from unicodedata import category
from selenium import webdriver
import time 
import xlrd
from xlutils.copy import copy
import pandas as pd 
import re
import os

name_arr = []
price_arr = []
link_arr = []
category_arr = []
category = 'Без категории'


#Открытие названиев товаров 
def open_ex():
  wb = xlrd.open_workbook("Рузанна.xlsx") # where vis.xls is your test file
  sheet = wb.sheet_by_index(0) 
  
  table =  sheet.nrows
  
  print(table)
  i = 13
  
  while table>i:
      os.system('cls||clear')
      name = sheet.cell_value(i, 3)
      
      price = sheet.cell_value(i, 4)
      if price =='':
          category = name
      if price != '':
        name_arr.append(name)

        price_arr.append(price)

        category_arr.append(category)

      

      

      

          
          
      
      

      print('Категории: {}'.format(category_arr),'Товары: {}'.format(name_arr),'Цены: {}'.format(price_arr))
      print('Сколько товаров осталось:{}'.format(table - i))
      img_draiver(name)

      i = i + 1
  if table == i:
      create_exsel()




def img_draiver(product_name):
  product_name =re.sub("[$|@|&]","",product_name)
  url = 'https://yandex.ru/images/search?text={}'.format(product_name)
  driver = webdriver.Chrome(executable_path="C:\\Users\\manpa\\OneDrive\\Рабочий стол\\python\\python exsel\\chromedriver_win32\\chromedriver")

  
  try:
      driver.get(url=url)
      element = driver.find_element_by_class_name("serp-item__thumb")
      image = element.get_attribute("src")
      link_arr.append(image)
      print(image)
      
      time.sleep(5)

  except Exception as ex:
      print(ex)

  finally:
      driver.close()
      driver.quit()


def create_exsel():
  df = pd.DataFrame({
      'Название товара': name_arr,
      'Цена товара': price_arr,
      'Фото': link_arr,
      'Категория': category_arr
  })
  df.to_excel('Рузанна_проверка.xlsx')
    


if __name__ == "__main__":
    open_ex()