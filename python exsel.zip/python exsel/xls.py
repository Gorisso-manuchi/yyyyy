from unicodedata import name
from xlutils.copy import copy
import xlrd
import pandas as pd 
import xlwt
name_arr = []
price_arr = []

def open_ex():
  wb = xlrd.open_workbook("Авангард.xlsx") # where vis.xls is your test file
  sheet = wb.sheet_by_index(0) 
  

  table =  sheet.nrows
  print(table)
  i = 5
  while table>i:
      name = sheet.cell_value(i, 4)
      price = sheet.cell_value(i, 13)

      print(name, price)
      name_arr.append(name)
      price_arr.append(price)
      

      i = i + 1
  df = pd.DataFrame({
      'Название товара': name_arr,
      'Цена товара': price_arr
  })
  df.to_excel('who.xlsx')


if __name__ == "__main__":
    open_ex()