from gettext import find
import pdb
from time import sleep
import time
from traceback import print_tb
from turtle import textinput
from unicodedata import category
import undetected_chromedriver
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from anticaptchaofficial.recaptchav2proxyless import *


def driver_market():
    
    url = 'https://www.google.com/search?hl=en&tbm=shop&sxsrf=ALiCzsYWNzzQESyH0i8KdDRzytewajypvA:1653939962804&q=Abercrombie+%26+Fitch+-+Authentic+Night+&tbs=mr:1,merchagg:m100484415&sa=X&ved=0ahUKEwiIoNm__of4AhUG-yoKHSW4AboQsysIuAgoAA&biw=1920&bih=912&dpr=1'
    driver = undetected_chromedriver.Chrome()
   # wait = WebDriverWait(driver, 20)
    driver.get(url)
    time.sleep(5)
    #driver.execute_script("""document.querySelector("#recaptcha-anchor > div.recaptcha-checkbox-border").click()""")
    sitekey = driver.find_element(by=By.CSS_SELECTOR, value = '#recaptcha').get_attribute('data-sitekey')
    print(sitekey)

    #click = driver.find_element(by=By.XPATH, value = '/html/body/div[2]/div[3]/div[1]/div/div/span/div[1]').click()

    solver = recaptchaV2Proxyless()

    solver.set_verbose(1)
    



    


    solver.set_key('6aababb0c3b6276bc0e0e3e603935821')
    Browser_url = driver.current_url
    solver.set_website_url(Browser_url)
    solver.set_website_key(sitekey)

    g__response = solver.solve_and_return_solution()

    if g__response != 0:
      print('g_response'+ g__response)

    else:
      print('task finished with error' + solver.error_code)
    
    driver.execute_script("""document.getElementById("g-recaptcha-response").innerHTML = arguments[0]""", g__response)
    driver.execute_script('var element=document.getElementById("g-recaptcha-response"); element.style.display="none";')
    





    


    time.sleep(55555)

  

    

    
    

    #ry:  
    # 
    # driver.get(url)
    # #wait.until(EC.presence_of_element_located((By.CLASS_NAME, 's-searchForm__field')))
    # time.sleep(5)
    # element = driver.find_elements(by=By.CSS_SELECTOR, value='div.pop') #узнать сколько товаров
    # for value in element:
    #   print(value.text)
    # img = driver.find_elements(by=By.CSS_SELECTOR, value = '.product-img-container.product-hero')
    # for i in img:
    #   print(i.get_attribute('src'))
    # 
    # sex = driver.find_elements(by=By.CSS_SELECTOR, value = 'table.ex_chars_table td > a')

    # for i in sex:
    #   print(i.text)
    #   if i.text == 'Женская':
    #     sex = i.text
    #   elif i.text == 'мужской':
    #     sex = i.text

    # print(sex)
   #  
   #  

   #  


   # 

   #except Exception as ex:
   #  print(ex)
   #finally:
   #  
   # driver.close()
   # driver.quit()




if __name__ == "__main__":
    driver_market()