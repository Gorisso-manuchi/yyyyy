from inspect import Attribute
import pdb
from time import sleep
import time
from traceback import print_tb
from turtle import textinput
from unicodedata import category
from xml.dom.minidom import TypeInfo
import undetected_chromedriver
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import sys,os
from datetime import datetime

df = pd.read_excel('Авангард.xlsx')#прайс который мы парсим 

Breand = ['A. Banderas','Abercrombie & Fitch','Armand Basi','Armani','Azzaro Chrome','Azzaro Wanted','Blumarine','Brioni','Bruno Banani','Bvlgari','Byredo','Cerruti 1881','Christina Aguilera','Clinique','CREED','D&G','By Kilian','DKNY','E. Arden','Franck Olivier','Ghost','Guess','Issey Miyake','Jennifer Lopez','John Varvatos','Lalique','Masaki M','Masaki Matsushima','Mexx','Moschino','Naomi Campbell','Narciso Rodriguez','NINA RICCI','Paloma Picasso','REMY LATOUR','Salvador Dali','Salvatore Ferragamo','Sisley','Tommy Hilfiger Tommy','Vanderbilt','YSL Y']#бренды


 # считает сколько строк в парсере
try: #загружаем последние данные если они есть если нет то выбросит исключение
  
  nb = pd.read_excel('who.xlsx')
  num_rown_who = nb.count()[0]
  i = 0 
  name_arr = []
  price_arr=[]
  link_arr = []
  brend_arr = []
  Description_arr=[]
  sku_arr = []
  sex_arr = []
  while num_rown_who>i:
    name_arr.append(nb['Название товара'].iloc[i])
    price_arr.append(nb['Цена товара'].iloc[i])
    link_arr.append(nb['Фото'].iloc[i])
    brend_arr.append(nb['Бренд'].iloc[i])
    Description_arr.append(nb['Описание'].iloc[i])
    sku_arr.append(nb['SKU'].iloc[i])
    sex_arr.append(nb['Пол'].iloc[i])
    i = i+1



except Exception as ex:
  print(ex)
  name_arr = []
  price_arr=[]
  link_arr = []
  brend_arr = []
  Description_arr=[]
  sku_arr = []
  sex_arr = []





def verification():
  

  try:
    table= nb.count()[0]
    item = 0
    while num_rown_who>item:
      item = item + 1

    if item == num_rown_who:
      return item

      


     






  except Exception:
    return 0



capa = DesiredCapabilities.CHROME
capa["pageLoadStrategy"] = "none"


def open_ex():
  print(df['Unnamed: 4'].iloc[5])

  num_rows = 163
  print(num_rows)
  i = verification() +4
  
  while i<num_rows:
   name = df['Unnamed: 4'].iloc[i]
   price = df['Unnamed: 13'].iloc[i]
 
   print(name)
   

   print(price)
   
   i = i +1
 
   driver_market(name,price)

   

def driver_market(product_name,price):
    start_time = datetime.now()
    time.sleep(5)
    url = 'https://randewoo.ru/'
    driver = undetected_chromedriver.Chrome(desired_capabilities=capa)
   # wait = WebDriverWait(driver, 20)
    try:  
      
      driver.get(url)
      #wait.until(EC.presence_of_element_located((By.CLASS_NAME, 's-searchForm__field')))
      
      
      time.sleep(5)
      TextInput = driver.find_element(by=By.CLASS_NAME, value='s-searchForm__field').send_keys('{}'.format(product_name))
      #self.send_keys('.s-searchForm__field','{}'.format(product_name))
      ButtonClick = driver.find_element(by=By.CLASS_NAME, value='s-searchForm__submit').click()
      
      
      
      #driver.execute_script("window.stop();")
      
      time.sleep(5)
      
      WordBreaking = product_name.split(' ')#переводим в список название продукта 
      TitleLength = len(WordBreaking)-1 #
      value = 0
      while value==0:
           
            WordBreaking.pop(TitleLength)
            TitleLength=TitleLength-1
            Join_Text =' '.join(WordBreaking)
    
            if Join_Text in Breand:
              name_arr.append('{}(Недоработанный)'.format(product_name))
              price_arr.append(0)
              link_arr.append(0)
              Description_arr.append(0)
              brend_arr.append(0)
              sku_arr.append(0)
              sex_arr.append(0)

              cc = pd.DataFrame({
              'Название товара': name_arr,
              'Цена товара': price_arr,
              'Фото': link_arr,
              'Описание':Description_arr,
              'Бренд':brend_arr,
              'SKU': sku_arr,
              'Пол': sex_arr
              })
              cc.to_excel('who.xlsx')


              
              break


            else:
               time.sleep(2)
               Search_Clear  = driver.find_element(by=By.CLASS_NAME, value='s-searchForm__clear').click()
               TextInput = driver.find_element(by=By.CLASS_NAME, value='s-searchForm__field').send_keys('{}'.format(Join_Text))
               ButtonClick = driver.find_element(by=By.CLASS_NAME, value='s-searchForm__submit').click()
               time.sleep(2)
               element = driver.find_elements(by=By.XPATH, value='//*[@id="catalog-filter"]/div[2]/ul/li[1]/div/div/b')
               for item in element:
                 value = item.text
               print(value)
                 

      print('1999')
      print(value)
      if  int(value) >0:
        

         time.sleep(4)
         Products_It =driver.find_elements(by=By.XPATH,value='//*[@id="products_cont"]/ul/li[1]/div/a[1]')[0].click()
         print(Products_It)

         time.sleep(5)

         sku = driver.find_elements(by=By.XPATH, value='//*[@id="app"]/div[2]/div[1]/main/article/div[3]/div/div[5]/div/div/dl/div[2]/dd')[0].text
         
         if driver.find_elements(by=By.XPATH, value='//*[@id="app"]/div[2]/div[1]/main/article/div[3]/div/div[5]/div/div/dl/div[3]/dd')[0].text == 'Для мужчин':
           sex = 'Мужская парфюмерия'
         elif driver.find_elements(by=By.XPATH, value='//*[@id="app"]/div[2]/div[1]/main/article/div[3]/div/div[5]/div/div/dl/div[3]/dd')[0].text == 'Для женщин':
           sex = 'Женская парфюмерия'

         
         print('zzzzz')

         if sku in sku_arr:
              name_arr.append('{}(Недоработанный)'.format(product_name))
              price_arr.append(0)
              link_arr.append(0)
              Description_arr.append(0)
              brend_arr.append(0)
              sku_arr.append(0)
              sex_arr.append(0)

              cc = pd.DataFrame({
              'Название товара': name_arr,
              'Цена товара': price_arr,
              'Фото': link_arr,
              'Описание':Description_arr,
              'Бренд':brend_arr,
              'SKU': sku_arr
              })
              cc.to_excel('who.xlsx')


           
         
             
         else:

             Description =  driver.find_elements(by=By.CLASS_NAME,value='collapsable')
         
             for item in Description:
               Description = item.text
               print(Description)
          
         
             Brends =driver.find_elements(by=By.XPATH,value='//*[@id="app"]/div[2]/div[1]/main/article/div[3]/div/div[5]/div/div/dl/div[1]/dd/a')[0].text
             print(Brends)

         
             link_img = driver.find_elements(by=By.CLASS_NAME, value = 'js-main-product-image')[0].get_attribute('src')
             print(link_arr)

         
             name_arr.append(product_name)
             price_arr.append(price)
             link_arr.append(link_img)
             Description_arr.append(Description)
             brend_arr.append(Brends)
             sku_arr.append(sku)
             sex_arr.append(sex)

         



             cc = pd.DataFrame({
             'Название товара': name_arr,
             'Цена товара': price_arr,
             'Фото': link_arr,
        
             'Описание':Description_arr,
             'Бренд':brend_arr,
             'SKU': sku_arr,
             'Пол': sex_arr
              })
         
             cc.to_excel('who.xlsx')











        
              


      
      

      
      
      time.sleep(2)


      
      
      
      
    except Exception as ex:
      print(ex)
      driver.close()
      driver.quit()
      
      from threading import Timer
      Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()
    finally:
      
     driver.close()
     driver.quit()




if __name__ == "__main__":
    open_ex()