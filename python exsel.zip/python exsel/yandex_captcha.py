from gettext import find
import pdb
from time import sleep
import time
from traceback import print_tb
from turtle import textinput
from unicodedata import category, name
import undetected_chromedriver
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from anticaptchaofficial.recaptchav2proxyless import *
import sys
import os

from twocaptcha import TwoCaptcha
categories_arr1 = ['dfklslf','d343']
def driver_market():
    while True:
    
      url = 'https://market.yandex.ru/product--abercrombie-fitch-parfiumernaia-voda-authentic-woman/545542184?glfilter=15927602%3A100~100_100767162827&text=%D0%BF%D0%B0%D1%80%D1%84%D1%8E%D0%BC%D0%B5%D1%80%D0%B8%D1%8F%20%D0%B4%D0%BB%D1%8F%20%D0%B6%D0%B5%D0%BD%D1%89%D0%B8%D0%BD&cpc=5n6XGOojFhe_GixCSqmoOkSAsAv1YUKaudgOnlrEVUlUy-N2Q58cAoPCGC7VK-JXMfr_E-EYX30B0G5l81mECOZGS7FDNJKnChyDvcGUP55mk_1o9Vq_d_zv3hvGgYRo1IxXQ5QQqc5XnfI15JhMztYVuQIDSF73_TU8ZwC_ixuHNGmbkejrJgle7SVA_HzJ&rs=eJyNVruqnUUYTUDJMVocDgTUKqRKOd9lvotP4VsELC1TRbCxUQTB17AwEtDgC6TY-3WsXHP5Z_5tZYpzzmYyM2vW7dv87YtXT19e_r78dn1z_f764-Wvy9vrm8u760_PL79f_my__ri8vby__nB5d3l__-svH568-Oju0f0j_Pz0_tnLx9_8781fP3798d0_P3948tV3z_iLh0-q1qpMofwZleLmZBzs_OXDU9KsTmTF2xpVcdLq-PT5wx0pW60ifVfNUrmm8lopVseKF3GLGmuFTecKPliJaCC4BM6yYudNlscmDR8XmZlHdd0rADH3VLIsWueKi3uOlYqTsJQbtg4IRhZUg9ZKSox7NEEDJUhZD1Jbp1UuedxjkaEbQSXZ9OAVN3tikdqeXQepnMRCUfua4d4CRfqJQEBpVnXtEw7xm32-but8DY4cerho3-UURMRR-lqSMKe7LpbMeewqwaoutM4rObjACeCIcflYwd88zVJIJAFoqwFQ_R7G_y_pufbAVx03eRrUXpx7wb_Jn4CmzLpxM4_Xdt2zkG49YJatoQbUgY2ocLgKT1dagkjB0jqwhg6SvMJS6SY3l419Cdmk4tAD_IKh2YRS89ODz24m0AsYKgGOC_O8KhEN5xWBUK2TP4M3CiTBpmaxoDIM2H4HbBojh86wFSJRt4gIwbRF1yFnRiXxZxFc1-gAl4FM0AbfVm-cRjdOO9R3ghg3D-sHdjMCl02e0BPAebI1jJw39lwmxGNw0smgKV2yYNzOrgM-YLWw83aH8Mw3BDI4XE7-9ENKwEo6yVwQ990XBlj9qlTN5ph-FaM4EHM_t5meLbUCVA2WKnmOiXXsgIdXws0TIRyPh-2qC5sIXVEfpxU1276GV2QlCGUyDdWs5a3DOogK5Xyal2AEaFd4QQ85rAH58SaYdKgl3j4utVrt0FAr2AQpjKFWMQEO9VMtjPdCztZrO67k_4lraVclqhuzIaYJER9QRnWlv4z0z_dmDq1aTsCM9pxQMwiUoq5VwmMwnYwHC8yrJcoSH6UzcxywXXVEtNOE0zCwdGQIlSOqilJY5M5iRbxq86ZMLqy18Vyr6A1g9y1W8mAQ1YI5574HCY_UzbHUuD0eXOvc0yyDPWeBZzvhudCEFnJuXVUn8oKCIzqSheOVxjDpn9D1ezRlTEeXwIrBj6sXiFuUjl4AtbNc5wgSOmc15bAa8MMsh9UMAaCNvxyB7O2KeMxdOCwibexS1BXOGAmCJMlZh0WpcYiqqzZlJqkRdJL5NN0h0pxBjm8ayZS7u9o3jpvuqidCZGUI0y6WrfvZUxbJaGccgmWxLSVSIyfTzB7X5qw2Vw9_Qq5yAHdDu9Fp5NZytKQhThiUe4ijym9acjWowSiW89tWbemEhceTTRr1ZSoWAvlKTqVrmxotOJ1fDJIAK3Zy3DGUKTCWcmtpfMw1gEINlf2tT3T67cA4qa_wLAQe-LX1CWDOThEp0hI849w4aF-oOidoKHy5zPnFBu2KpmT7F8ONKI8%2C&sku=100767162827&do-waremd5=1671LRCS7KJbmJa_VgPpXg&cpa=1&nid=16677491'
     
      
      driver.get(url)
      time.sleep(5)
      try:
      
        driver.execute_script('''document.querySelector("#root > div > div > div.Spacer.Spacer_auto-gap_bottom > div > form > div > div.CheckboxCaptcha-Anchor > input").click()''')
        time.sleep(5)
        img =driver.find_elements(by=By.CSS_SELECTOR, value = 'img.AdvancedCaptcha-Image')[0].get_attribute('src')
        print(img)
        sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

      

        api_key = os.getenv('APIKEY_2CAPTCHA', '434a29710a6d779ab77cf72c27d4352f')

        solver = TwoCaptcha(api_key)

        try:
            result = solver.normal(img)
            result = result["code"]
            print(result)
            driver.find_elements(by=By.CSS_SELECTOR, value = 'input.Textinput-Control')[0].send_keys('{}'.format(result))
            driver.execute_script('''document.querySelector("#root > div > div > div.AdvancedCaptcha > form > div.AdvancedCaptcha-FormActions > button.Button2.Button2_view_action.Button2_size_l").click()''')
            time.sleep(5)

            categories =  driver.find_elements(by=By.CSS_SELECTOR, value = 'ul._2m7_o._1lmw2 >li')
            categories_arr = []
            for i in categories:
              categories_arr.append(i.text)

            sex  = driver.find_elements(by=By.CSS_SELECTOR, value = 'td._3M0mF > a')
            for i in sex:
              if i.text == 'женский':
                categories_arr.append('Женская парфюмерия')
              elif i.text == 'мужской':
                categories_arr.append('Мужская парфюмерия')
              elif i.text == 'унисекс':
                categories_arr.append('Унисекс')


              
                
            
            categories  = ",".join(categories_arr)
            categories_arr1.append(categories)
            print(categories_arr1)






                
            

        except Exception as e:
           sys.exit(e)

        else:
          sys.exit('solved: ' + str(result))
        
      except Exception as ex:
        
      
        
        
        categories = driver.find_elements(by=By.CSS_SELECTOR, value = 'ul._2m7_o._1lmw2 >li')
        print(categories)
        
        

        print(ex)
      

    
    





    


      

  

    

    




if __name__ == "__main__":
    driver = undetected_chromedriver.Chrome()
    driver_market()