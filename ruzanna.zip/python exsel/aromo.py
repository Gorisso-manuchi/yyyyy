from inspect import Attribute
import pdb
from time import sleep
import time
from traceback import print_tb
from turtle import textinput
from unicodedata import category
from xml.dom.minidom import TypeInfo
import undetected_chromedriver
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import sys,os
from datetime import datetime


df = pd.read_excel('Авангард.xlsx')



#capa = DesiredCapabilities.CHROME
#capa["pageLoadStrategy"] = "none"


def open_ex():
  print(df['Unnamed: 4'].iloc[5])

  num_rows = 163
  print(num_rows)
  i = 4
  
  while i<num_rows:
   name = df['Unnamed: 4'].iloc[i]
   price = df['Unnamed: 13'].iloc[i]
 
   print(name)
   

   print(price)
   
   i = i +1
 
   driver_market(name,price)



def driver_market(product_name,price):
    start_time = datetime.now()
    time.sleep(5)
    url = 'https://aromo.ru/'
    driver = undetected_chromedriver.Chrome()
   # wait = WebDriverWait(driver, 20)
    try:  
      
      driver.get(url)
      #wait.until(EC.presence_of_element_located((By.CLASS_NAME, 's-searchForm__field')))

      
      
      
      time.sleep(5)
      TextInput = driver.find_element(by=By.CLASS_NAME, value='search__input').send_keys('{}'.format(product_name)) #название товара из прайса кидаем сюда)
      loading = driver.find_element(by=By.CLASS_NAME, value= 'search__input').get_attribute('data-state') # узнаем статус загрузки
      

      
      time.sleep(5)
      while loading =='loading':# пока состояние загрузки каждую секунду обновляем пока не будет результ
         
          
          loading = driver.find_element(by=By.CLASS_NAME, value= 'search__input').get_attribute('data-state')
          print(loading)
      
      if loading == 'results':
        time.sleep(5)
        finds_len= len(driver.find_elements(by=By.CLASS_NAME, value='results-column-wrapper__caption')) # есть ли товары 
        
        if finds_len>0: # если есть, то  считаем сколько их 
            products_click = driver.find_elements(by=By.CLASS_NAME, value='search-perfume__name')
            coincidence = {}
            for i, product in enumerate(products_click):
                n = 0
                product = product.text.lower().split(' ')
                WordBreaking = product_name.lower().split(' ')
                for b in WordBreaking:
                    for c in product:  
                        if b==c:
                            n = n+1
                
                coincidence[i]=n

            def get_key(d, value):
              for k, v in d.items():
                if v == value:
                  return k

            max_number =  max(coincidence.values())
            index_coin = get_key(coincidence, max_number)

            tupo = products_click[index_coin].get_attribute('href')
            print(tupo)
            time.sleep(10)
                

            

                


                    
                    

                

        elif finds_len==0:
            print('привет')
          

        





      print(loading)
      


      

    except Exception as ex:
      print(ex)
      driver.close()
      driver.quit()
      
      from threading import Timer
      Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()
    finally:
      
     driver.close()
     driver.quit()




if __name__ == "__main__":
    open_ex()