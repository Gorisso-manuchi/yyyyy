from asyncore import read
from email.mime import image
from lib2to3.pgen2 import driver
from unicodedata import category
from selenium import webdriver
import time 
import xlrd
from xlutils.copy import copy
import pandas as pd 
import re
import os

name_arr = []
price_arr = []
link_arr = []
category_arr = []
category = 'Без категории'


#Открытие названиев товаров 
def open_ex():
  wb = xlrd.open_workbook("проверка.xls") # where vis.xls is your test file
  sheet = wb.sheet_by_index(0) 
  
  table =  sheet.nrows
  
  print(table)
  i = 13
  
  while table>i:
      os.system('cls||clear')
      name = sheet.cell_value(i, 3)
      
      price = sheet.cell_value(i, 4)
      
      link = sheet.cell_value(i,5)
      
      name_arr.append(name)

      price_arr.append(price)

      link_arr.append(link)

      

      

      

          
          
      
      

     
      

      i = i + 1
  if table == i:
      create_exsel()






def create_exsel():
  df = pd.DataFrame({
      'Название товара': name_arr,
      'Цена товара': price_arr,
      'Фото': link_arr,
      
  })
  df.to_excel('Рузанна_проверка99.xlsx')
    


if __name__ == "__main__":
    open_ex()