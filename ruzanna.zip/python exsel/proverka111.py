
from itertools import count
from multiprocessing.sharedctypes import Value
from unicodedata import name

import pandas as pd
import numpy as np

df = pd.read_excel('who.xlsx')
i = 0
num_rown = df.count()[2]

print(num_rown)
name_arr = []
try:
   while num_rown>i:
      name_arr.append(df['Цена товара'].iloc[i])
      

      i=i+1
      print(name_arr)
except IndexError:





name_arr = []  
price_arr=[]
link_arr = []
brend_arr = []
Description_arr=[]