#! /usr/bin/env python
# -*- coding: utf-8 -*-


from dbm import dumb
from inspect import Attribute
from itertools import product
from multiprocessing.sharedctypes import Value
import pdb
from time import sleep
import time
from traceback import print_tb
from turtle import textinput
from unicodedata import category
from webbrowser import BaseBrowser
from xml.dom.minidom import TypeInfo
import undetected_chromedriver
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import sys,os
from datetime import datetime
import re
from urllib.parse import urlparse
import sys
import os
import undetected_chromedriver as uc

from twocaptcha import TwoCaptcha
#безголовый запуск
options = webdriver.ChromeOptions()
options.add_argument('--no-sandbox')



df = pd.read_excel('Ruzanna55.xlsx')
#массивы которые будут загружаться данными для переноса на новый прайс лист#_________________________
name_arr = []
price_arr=[]
link_arr = []
categories_arr = []

Description_arr=[]


#загружаем последние данные если они есть если нет то выбросит исключение_______________



try: 
  nb = pd.read_excel('who.xlsx')
  num_rown_who = nb.count()[0]
  i = 0 
  while num_rown_who>i:
    name_arr.append(nb['Название товара'].iloc[i])
    price_arr.append(nb['Цена товара'].iloc[i])
    link_arr.append(nb['Фото'].iloc[i])
    Description_arr.append(nb['Описание'].iloc[i])
    categories_arr.append(nb['Категории'].iloc[i])
    
    i = i+1
  
except Exception as ex:
  print(ex)
  name_arr = []
  price_arr=[]
  link_arr = []
  categories_arr = []
  Description_arr=[]



#______________________________________________________________________________

def captcha():
  try:
     
     driver.execute_script('''document.querySelector("#root > div > div > div.Spacer.Spacer_auto-gap_bottom > div > form > div > div.CheckboxCaptcha-Anchor > input").click()''')
     time.sleep(5)
     img =driver.find_elements(by=By.CSS_SELECTOR, value = 'img.AdvancedCaptcha-Image')[0].get_attribute('src')
     print(img)
     sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))

      

     api_key = os.getenv('APIKEY_2CAPTCHA', '434a29710a6d779ab77cf72c27d4352f')

     solver = TwoCaptcha(api_key)

        
     result = solver.normal(img)
     result = result["code"]
     print(result)
     driver.find_elements(by=By.CSS_SELECTOR, value = 'input.Textinput-Control')[0].send_keys('{}'.format(result))
     driver.execute_script('''document.querySelector("#root > div > div > div.AdvancedCaptcha > form > div.AdvancedCaptcha-FormActions > button.Button2.Button2_view_action.Button2_size_l").click()''')
    


                
            

        
  except Exception as ex:
    
    print('нет капчи')
    

def verification():#Функция последний товар по индексу__________________________________
  try:
    table= nb.count()[0]
    item = 0
    while num_rown_who>item:
      item = item + 1
    if item == num_rown_who:
      return item
  except Exception:
    return 0
#_____________________________________________________________________________________
#Читаем прайс лист который нужен нам
def open_ex():
  
  print(df['Название товара'].iloc[5])
  
  num_rows = 2066
  
  i =  verification()
  
  while i<num_rows:
   name = df['Название товара'].iloc[i]
   price = df['Цена товара'].iloc[i]
   
 
   print(name)
   

   print(price)
   
   i = i +1
 
   driver_market(name,price)
#------------------------------------------------------------------------------------------------

# Открываем драйвер selenium
#________________________________________________________________________________________________
def driver_market(name,price):
 try:
    url = 'https://market.yandex.ru/'
    driver.get(url)
    time.sleep(2)
    captcha()
    time.sleep(3)
    

    search = driver.find_elements(by=By.CSS_SELECTOR, value = 'input#header-search')[0].send_keys('{}'.format(name))#фотка

    poisk = driver.find_elements(by=By.CSS_SELECTOR, value = 'button._1Dyrh._1NDr9._3MZAj.V9ceN.wQgEg._1Himk.sQ_gr._2YKh4._3O-ed.G12sD._9Lboa._3ofRm._1XiEJ.mini-suggest__button')[0].click()
    
    time.sleep(5)
    captcha()
    len_products =  len(driver.find_elements(by=By.CSS_SELECTOR, value = 'a._2f75n._24Q6d.cia-cs'))
    if len_products > 0:
      click_product = driver.find_elements(by=By.CSS_SELECTOR, value = 'a._2f75n._24Q6d.cia-cs')[0].get_attribute('href')
      driver.get(click_product)
      captcha()
      time.sleep(5)
    
    
      description = driver.find_elements(by=By.CSS_SELECTOR, value = 'div._1uLae')
      for i in description:
        description = i.text

      if len(description) ==0:
        description ='0'
    
      print(description)
    

      img = driver.find_elements(by=By.CSS_SELECTOR, value = 'img._3Wp6V')
    
      for i in img:
        img = i.get_attribute('src')

      categories =  driver.find_elements(by=By.CSS_SELECTOR, value = 'ul._2m7_o._1lmw2 >li')
      categori_arr = []
      for i in categories:
        categori_arr.append(i.text)

      sex  = driver.find_elements(by=By.CSS_SELECTOR, value = 'td._3M0mF > a')
      for i in sex:
        if i.text == 'женский':
          categori_arr.append('Женская парфюмерия')
        elif i.text == 'мужской':
          categori_arr.append('Мужская парфюмерия')
        elif i.text == 'унисекс':
          categori_arr.append('Унисекс')


      
      categories  = ",".join(categori_arr)
      print(img)
      
      name_arr.append(name)
      price_arr.append(price)
      link_arr.append(img)
      Description_arr.append(description)
      categories_arr.append(categories)
      print(categories_arr)
      create_ex(name_arr,price_arr,link_arr,Description_arr,categories_arr)

      time.sleep(5)
    else:
      name_arr.append(name)
      price_arr.append(price)
      link_arr.append('https://image-cdn.kazanexpress.ru/bti8bhnqo07bc3qcner0/original.jpg')
      Description_arr.append(0)
      categories_arr.append('Без категории')
      create_ex(name_arr,price_arr,link_arr,Description_arr,categories_arr)
      

    


    
        
          
          
         

 

 except Exception as ex:
    print(ex)
    driver.close()
    driver.quit()
    from threading import Timer
    Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()

#----------------------------------------------------------



def create_ex(name_arr,price_arr,link_arr,Description_arr,categories_arr):
  try:
    cc = pd.DataFrame({
    'Название товара': name_arr,
    'Цена товара': price_arr,
    'Фото': link_arr,    
    'Описание':Description_arr,
    'Категории': categories_arr
    
    
  
   })       
    cc.to_excel('who.xlsx')
    

  except Exception as ex:
    print(ex)
    from threading import Timer
    Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()



if __name__ == "__main__":
    options = webdriver.ChromeOptions() 
    options.headless = True
    driver = uc.Chrome(options=options)# options=chrome_options добавить если вы хотите безголовый запуск
    open_ex()
    