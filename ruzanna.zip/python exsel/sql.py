import sqlite3
from numba import njit
def connect_db(item, name, price, link):# записываем данные в бд
   with sqlite3.connect('db/database.db') as db:#db,db3,sqlite,sqlite3
       cursor = db.cursor()

       query = """ INSERT INTO avangard (id, name, price, link)  VALUES (?, ?, ?, ?)"""
       
       print(item, name, price, link)
       print('БД')
       cursor.execute(query, (item, name, price, link))

       db.commit()



def read_db():# читаем бд и находим последний пост если он найдем парсер с него начинает
    with sqlite3.connect('db/database.db') as db:#db,db3,sqlite,sqlite3
      try:
         cursor = db.cursor()
         r = cursor.execute('SELECT id FROM avangard').fetchall()     
       
         return r[len(r)-1][0] 
      except IndexError:
          return 6


#Прайс рузанна

def connect_db_ruzanna(item, name, price, link, category,db):
       print('зашел1')
       cursor = db.cursor()
       print('зашел2')
       query = """ INSERT INTO ruzanna (id, name, price, link, category)  VALUES (?, ?, ?, ?, ?)"""
       print('зашел3')
       #print(item, name, price, link, category)
       #print('БД')
       cursor.execute(query, (item, name, price, link, category))
       print('зашел4')
       db.commit()


def read_db_ruzanna(db):# читаем бд и находим последний пост если он найдем парсер с него начинает
      try:
         cursor = db.cursor()
         r = cursor.execute('SELECT id FROM ruzanna').fetchall()     
       
         return r[len(r)-1][0] 
      except IndexError:
         return 12

def categories_read(db):
    
      try:
         cursor = db.cursor()
         r = cursor.execute('SELECT category FROM ruzanna').fetchall()     
       
         return r[len(r)-1][0] 
      except IndexError:
         return 'Abercrombie & Fitch'



# создание таблицы
#with sqlite3.connect('db/database.db') as db:#db,db3,sqlite,sqlite3
# cursor = db.cursor()
#  query  = """CREATE TABLE IF NOT EXISTS ruzanna  (id INTEGER, name TEXT, price INTEGER, link TEXT,category TEXT)"""
#  cursor.execute(query)