#from asyncore import read
#from email.mime import image
#from lib2to3.pgen2 import driver
from cgi import print_arguments
from sqlite3 import connect
#from selenium import webdriver
import undetected_chromedriver
import time 
import xlrd
#from xlutils.copy import copy
#import pandas as pd 
import re
import sql
#import os
import sqlite3
from numba import njit




name_arr = ''
price_arr = ''
link_arr = [12]
category_arr = ''
category = 'Без категории'

#Открытие названиев товаров 

def open_ex():
  wb = xlrd.open_workbook("Рузанна.xlsx") # where vis.xls is your test file
  sheet = wb.sheet_by_index(0) 
  
  table =  sheet.nrows
  print(table)
  
  with sqlite3.connect('db/database.db') as db:
    
    i = sql.read_db_ruzanna(db) +1
    category = sql.categories_read(db)
    print('Это число:', i)
    while table>i:
      
        cur_time = time.time()
        name = sheet.cell_value(i, 3)
      
        price = sheet.cell_value(i, 4)
      
        if price =='':
            category = name
         
        if price != '':
      
          name_arr= name
          price_arr = price
      
          img_draiver(name)
          print(name_arr,price_arr,link_arr[0], 'openex')
       
          sql.connect_db_ruzanna(i, name_arr, price_arr,link_arr[0], category,db)

        
          
          print('Категории: {}'.format(category),'Товары: {}'.format(name_arr),'Цены: {}'.format(price_arr), 'Время выполнение:{}'.format(time.time()- cur_time))
          print('Сколько товаров осталось:{}'.format(table - i))



        i = i + 1
 # if table == i:
#     break


def img_draiver(product_name):
  
  product_name =re.sub("[$|@|&]","",product_name)
  url = 'https://yandex.ru/products/search?text={}'.format(product_name)
  #chrome_options = webdriver.ChromeOptions()
  #chrome_options.add_argument("--incognito")
  
  #driver = webdriver.Chrome(executable_path="C:\\Users\\manpa\\OneDrive\\Рабочий стол\\python\\python exsel\\chromedriver_win32\\chromedriver",chrome_options=chrome_options)
  driver = undetected_chromedriver.Chrome()
  
  
  
  try:
      
      driver.get(url)
      
      
      time.sleep(5)
      element = driver.find_element_by_class_name("Thumbnail-Image")
      image = element.get_attribute("src")

      
      
      #element.click()
      #time.sleep(3)
      #description = driver.find_element_by_css_selector("div.ListCut-Items > dl:nth-of-type(2)").text 
      #print(description)
      
      
      link_arr[0]= image
      
      
      
      
  except Exception as ex:
      driver.close()
      driver.quit()
      driver = undetected_chromedriver.Chrome()
      print('kkkk')
       
      url = 'https://yandex.ru/images/search?text={}'.format(product_name)
      print(url)
      time.sleep(5)
      driver.get(url)

      element = driver.find_element_by_class_name("serp-item__thumb")
      image = element.get_attribute("src")
      link_arr[0]= image
       


      
      
       
    



      
      
      
      


  
      
    
  

  finally:
      
     driver.close()
     driver.quit()


#def create_exsel():
#  df = pd.DataFrame({
#      'Название товара': name_arr,
#      'Цена товара': price_arr,
#      'Фото': link_arr 
#  })
#  df.to_excel('who.xlsx')
    


if __name__ == "__main__":
    
    open_ex()