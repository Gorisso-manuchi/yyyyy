from asyncore import read
from email.mime import image
from lib2to3.pgen2 import driver
from sqlite3 import connect
#from selenium import webdriver
import undetected_chromedriver
import time 
import xlrd
from xlutils.copy import copy
import pandas as pd 
import re
import sql
import os





name_arr = ''
price_arr = ''
link_arr = [12]
#Открытие названиев товаров 
def open_ex():
  wb = xlrd.open_workbook("Авангард.xlsx") # where vis.xls is your test file
  sheet = wb.sheet_by_index(0) 
  
  table =  sheet.nrows
  print(table)
  i = sql.read_db() +1
  print('Это число:', i)
  while table>i:
      
      os.system('cls||clear')
      name = sheet.cell_value(i, 4)
      price = sheet.cell_value(i, 13)
      name_arr= name
      price_arr = price
      
      img_draiver(name)
      print(name_arr,price_arr,link_arr[0], 'openex')
       
      sql.connect_db(i, name_arr, price_arr,link_arr[0])



      i = i + 1
 # if table == i:
#     break




def img_draiver(product_name):
  
  product_name =re.sub("[$|@|&]","",product_name)
  url = 'https://yandex.ru/products/search?text={}'.format(product_name)
  #chrome_options = webdriver.ChromeOptions()
  #chrome_options.add_argument("--incognito")
  
  #driver = webdriver.Chrome(executable_path="C:\\Users\\manpa\\OneDrive\\Рабочий стол\\python\\python exsel\\chromedriver_win32\\chromedriver",chrome_options=chrome_options)
  driver = undetected_chromedriver.Chrome()
  
  
  
  try:
      
      driver.get(url)
      element = driver.find_element_by_class_name("Thumbnail-Image")
      image = element.get_attribute("src")
      
      #element.click()
      #time.sleep(3)
      #description = driver.find_element_by_css_selector("div.ListCut-Items > dl:nth-of-type(2)").text 
      #print(description)
      
      
      link_arr[0]= image
      
      
      
      time.sleep(5)
  except Exception as ex:
      
      print(ex)
      print('Капча!!')
      driver.close()
      driver.quit()
      open_ex()
      


  
      
    
  

  finally:
      
     driver.close()
     driver.quit()


#def create_exsel():
#  df = pd.DataFrame({
#      'Название товара': name_arr,
#      'Цена товара': price_arr,
#      'Фото': link_arr 
#  })
#  df.to_excel('who.xlsx')
    


if __name__ == "__main__":
    open_ex()