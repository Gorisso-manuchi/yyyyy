from dbm import dumb
from inspect import Attribute
from itertools import product
from multiprocessing.sharedctypes import Value
import pdb
from time import sleep
import time
from traceback import print_tb
from turtle import textinput
from unicodedata import category
from webbrowser import BaseBrowser
from xml.dom.minidom import TypeInfo
import undetected_chromedriver
import pandas as pd
import numpy as np
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
import sys,os
from datetime import datetime
import re
from selenium.webdriver.chrome.options import Options
from urllib.parse import urlparse
from anticaptchaofficial.recaptchav2proxyless import *
#безголовый запуск
#chrome_options = Options()
#chrome_options.add_argument("--headless")





df = pd.read_excel('Ruzanna55.xlsx')
#массивы которые будут загружаться данными для переноса на новый прайс лист#_________________________
name_arr = []
price_arr=[]
link_arr = []
brend_arr = []
Description_arr=[]
sex_arr = []

#загружаем последние данные если они есть если нет то выбросит исключение_______________



try: 
  nb = pd.read_excel('who.xlsx')
  num_rown_who = nb.count()[0]
  i = 0 
  while num_rown_who>i:
    name_arr.append(nb['Название товара'].iloc[i])
    price_arr.append(nb['Цена товара'].iloc[i])
    link_arr.append(nb['Фото'].iloc[i])
    brend_arr.append(nb['Бренд'].iloc[i])
    Description_arr.append(nb['Описание'].iloc[i])
    sex_arr.append(nb['Пол'].iloc[i])
    i = i+1
  
except Exception as ex:
  print(ex)
  name_arr = []
  price_arr=[]
  link_arr = []
  brend_arr = []
  Description_arr=[]
  sex_arr = []



#______________________________________________________________________________

def captcha():
  try:
     Browser_url = driver.current_url
     sitekey = driver.find_element(By.XPATH, value = '//*[@id="recaptcha"]').get_attribute('outerHTML')
     site_clear = sitekey.split('" data-callback')[0].split('data-sitekey="')[1]
     print(site_clear)

     solver = recaptchaV2Proxyless()
     solver.set_verbose(1)
     solver.set_key(os.environ["6aababb0c3b6276bc0e0e3e603935821"])
     solver.set_website_url(url)
     solver.set_website_key(site_clear)

     g_response = solver.solve_and_return_solution()

     if g_response!= 0:
       print("Получен ответ" + g_response)
     else:
       print('task finished with error' + solver.error_code)
     print('зашел')
     driver.execute_script('var element=document.getElementById("g-recaptcha-response"); element.style.display="";')

     driver.execute_script("""document.getElementById("g-recaptcha-response").innerHTML = arguments[0]""", g_response)
     driver.execute_script('var element=document.getElementById("g-recaptcha-response"); element.style.display="none";')

     driver.find_element(By.XPATH, '//*[@id="recaptcha-demo-submit"]').click()

     time.sleep(20)
  except Exception as ex:
    
    print(ex)
    

def verification():#Функция последний товар по индексу__________________________________
  try:
    table= nb.count()[0]
    item = 0
    while num_rown_who>item:
      item = item + 1
    if item == num_rown_who:
      return item
  except Exception:
    return 0
#_____________________________________________________________________________________
#Читаем прайс лист который нужен нам
def open_ex():
  
  print(df['Название товара'].iloc[5])
  
  num_rows = 2066
  
  i =  verification()
  
  while i<num_rows:
   name = df['Название товара'].iloc[i]
   price = df['Цена товара'].iloc[i]
   brend = df['Категория'].iloc[i]
 
   print(name)
   

   print(price)
   
   i = i +1
 
   driver_market(name,price,brend)
#------------------------------------------------------------------------------------------------

# Открываем драйвер selenium
#________________________________________________________________________________________________
def driver_market(name,price,brend):
    sex =  'Унисекс'

    url = 'https://www.google.ru/search?newwindow=1&hl=en&tbm=shop&sxsrf=ALiCzsYK3DgthkyvKXaPnqANlqwr6AwTFQ:1653310977492&q=A.+Banderas+The++Secret+Temptation+&tbs=mr:1,merchagg:g100704023%7Cm10456163&sa=X&ved=0ahUKEwjlqJCs1_X3AhXmxIsKHUaLDTgQsysI2AgoBw&biw=1920&bih=969&dpr=1'
    
   # wait = WebDriverWait(driver, 20)
    try:  
        
      product = re.sub("[^A-Za-z]", " ", name) # удаляем все цифры и символы и заменяе их на пустую строку
      tobo = ['men', 'm','man','edt','edp','w','women','ml','woman']
      men  = ['men', 'm','man'] # Мужские теги
      woman = ['w','women','woman'] 
      track = product.lower().split(' ') 
      print(track)
      
      
      product_name =  []
      for i in track:# удаляем слова которые мешают поиску
          print(i)
          if i == 'edt':
            product_name.append('Eau De Toilette')
           
          elif i == 'edp':
            product_name.append('Eau De Parfum')

          elif i in men:
            sex = 'Мужская парфюмерия'
            product_name.append('Men')

          elif i in woman:
            sex = 'Женская парфюмерия'
            product_name.append('Woman')
            
          elif i in tobo:
              continue       
          
          else:
              product_name.append(i)

        
          
          
         

      product_name = ' '.join(product_name) # Превращаем строку
      
      print(product_name, 'kkdlkdlk')

          
      
      
      driver.get(url)
      time.sleep(5)
      #Тут должны быть капчи 
      #wait.until(EC.presence_of_element_located((By.CLASS_NAME, 's-searchForm__field')))
      clear = driver.find_elements(by=By.CSS_SELECTOR, value = 'span.ExCKkf.z1asCe.rzyADb')[0].click()
      
      search = driver.find_elements(by=By.CSS_SELECTOR, value = 'input.gLFyf.gsfi')[0].send_keys('{}'.format(product_name))#фотка

      poisk = driver.find_elements(by=By.CSS_SELECTOR, value = 'button.Tg7LZd')[0].click()
      time.sleep(5)
      label = driver.find_elements(by=By.CSS_SELECTOR, value = 'span.lg3aE')
      
      
      shop = []
      for i in label:
        text = i.get_attribute('title')
        print(text)
        shop.append(text)
        #print(label_click[n])
        
        #if text =='Wildberries.ru':
          
         # url = label_click[n].get_attribute('href')
         # break

      shop_check(name,price,sex,shop,brend)
     # driver.get(wilberic)
    except Exception as ex:
        print(ex)
        driver.close()
        driver.quit()

        from threading import Timer
        Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()
    
    #finally:
     #driver.close()
     #driver.quit()

#-----------------------------------------------------------------------------------------------------------------------

#_______________________________Проверка_магазинов____________________________________________________________________
def shop_check(name,price,sex,shop,brend):
  label_click = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.vjtvke.ch6u2b')
  print(name)
  if 'Aroma-Butik.ru' in shop:
        index = shop.index('Aroma-Butik.ru')
        url = label_click[index].get_attribute('href')
        driver.get(url)

      
        time.sleep(1)
      
        click_to_shop = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.shntl')[0].get_attribute('href')
      
        driver.get(click_to_shop)
        #_________________ПРОВЕРКА URL БРАУЗЕРА
        Browser_url = driver.current_url
     
        t = urlparse(Browser_url).netloc
        Browser_url = '.'.join(t.split('.')[-2:])
        time.sleep(1)
      
        if 'aroma-butik.ru' == Browser_url:
          aroma_butik(name,price,sex,brend)
        else:
          link_to_randewoo = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.D4MQ1')[0].get_attribute('href')
          driver.get(link_to_randewoo)
          time.sleep(1)
          aroma_butik(name,price,sex,brend)
  elif  'Randewoo' in shop:
        index = shop.index('Randewoo')
        url = label_click[index].get_attribute('href')
        driver.get(url)

      
        time.sleep(1)
      
        click_to_shop = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.shntl')[0].get_attribute('href')
      
        driver.get(click_to_shop)
        #_________________ПРОВЕРКА URL БРАУЗЕРА
        Browser_url = driver.current_url
     
        t = urlparse(Browser_url).netloc
        Browser_url = '.'.join(t.split('.')[-2:])
        time.sleep(1)
      
        if 'randewoo.ru' == Browser_url:
          randewoo(name,price,sex,brend)
        else:
          link_to_randewoo = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.D4MQ1')[0].get_attribute('href')
          driver.get(link_to_randewoo)
          time.sleep(1)
          randewoo(name,price,sex,brend)

  

  elif  'Wildberries.ru' in shop:
        index = shop.index('Wildberries.ru')
        url = label_click[index].get_attribute('href')
        driver.get(url)

      
        time.sleep(1)
      
        click_to_shop = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.shntl')[0].get_attribute('href')
      
        driver.get(click_to_shop)
        #_________________ПРОВЕРКА URL БРАУЗЕРА
        Browser_url = driver.current_url
     
        t = urlparse(Browser_url).netloc
        Browser_url = '.'.join(t.split('.')[-2:])
        time.sleep(1)
      
        if 'wildberries.ru' == Browser_url:
          wildberries(name,price,sex,brend)
        else:
          link_to_randewoo = driver.find_elements(by=By.CSS_SELECTOR, value = 'a.D4MQ1')[0].get_attribute('href')
          driver.get(link_to_randewoo)
          time.sleep(1)
          wildberries(name,price,sex,brend)
  else:
    not_processed(name,price)


#_________________________________МАГАЗИНЫ_________________________________________________________________________________

#____________________________aroma-butik.ru________________________
def aroma_butik(name, price, sex,brend):
      description = driver.find_elements(by=By.CSS_SELECTOR, value='div.ex_long_text') #узнать сколько товаров
      for value in description:
        description = value.text
      img = driver.find_elements(by=By.CSS_SELECTOR, value = '.ex_link img')
      for i in img:
        print(i.get_attribute('src'))
        img = i.get_attribute('src')
        
      
      
      sex = driver.find_elements(by=By.CSS_SELECTOR, value = 'table.ex_chars_table td > a')
    
      for i in sex:
        print(i.text)
        if i.text == 'женский':
          sex = i.text
        elif i.text == 'мужской':
          sex = i.text

      append_arr(name,price,img,description,brend,sex)
# ________________________RANDEWOO_____________________________     
def randewoo(name,price,sex,brend):
  description =  driver.find_elements(by=By.CLASS_NAME,value='collapsable')
         
  for item in description:
      description = item.text
      print(description)
          
         
  brend =driver.find_elements(by=By.XPATH,value='//*[@id="app"]/div[2]/div[1]/main/article/div[3]/div/div[5]/div/div/dl/div[1]/dd/a')[0].text
  print(brend)

         
  img = driver.find_elements(by=By.CLASS_NAME, value = 'js-main-product-image')[0].get_attribute('src')
  
  append_arr(name,price,img,description,brend,sex)# передаем значение  в функции для запись в массив
      

#_____________WILBERRIES_______________________________________________________________________________________________
def wildberries(name,price,sex,brend):
  description = driver.find_elements(by=By.CSS_SELECTOR, value = 'p.collapsable__text')# описание товара wilberis
      
  for i in description:
    description = i.text

  img = driver.find_elements(by=By.CSS_SELECTOR, value = 'div.slide__content.img-plug.j-wba-card-item img')
  for i in img:
    img = i.get_attribute('src')
        
  brend = driver.find_elements(by=By.CSS_SELECTOR, value= 'h1.same-part-kt__header span')
  print(brend)
  for i in brend:
    pafo = i.get_attribute('data-link')

    if pafo == 'text{:product^brandName}':
        brend = i.text

  append_arr(name,price,img,description,brend,sex)# передаем значение  в функции для запись в массив

#__________________________________________ДОБАВЛЕНИЕ В МАССИВ_______________________________________    
def append_arr(name, price, img, description,brend,sex):
  name_arr.append(name)
  price_arr.append(price)
  link_arr.append(img)
  Description_arr.append(description)
  brend_arr.append(brend)
  sex_arr.append(sex)
  create_ex(name_arr,price_arr,link_arr,Description_arr,brend_arr,sex_arr)

    
    
# запись в прайс лист созданный в pandas
#_______________________________________________________
#____________________________необработанные товары_________________
def not_processed(name,price):
  try:
    name_arr.append('{}(Недоработанный)'.format(name))
    price_arr.append(price)
    link_arr.append('нету')
    Description_arr.append('нету')
    brend_arr.append('нету')
    sex_arr.append('нету')
  
    cc = pd.DataFrame({
    'Название товара': name_arr,
    'Цена товара': price_arr,
    'Фото': link_arr,    
    'Описание':Description_arr,
    'Бренд':brend_arr,
    'Пол': sex_arr
  
   })       
    cc.to_excel('who.xlsx')
  except Exception as ex:
    print(ex)
    from threading import Timer
    Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()



def create_ex(name_arr,price_arr,link_arr,Description_arr,brend_arr,sex_arr):
  try:
    cc = pd.DataFrame({
    'Название товара': name_arr,
    'Цена товара': price_arr,
    'Фото': link_arr,    
    'Описание':Description_arr,
    'Бренд':brend_arr,
    'Пол': sex_arr
  
   })       
    cc.to_excel('who.xlsx')
    

  except Exception as ex:
    print(ex)
    from threading import Timer
    Timer(2.0, lambda: os.execv(sys.executable, [sys.executable] + sys.argv)).start()

#----------------------------------------------------------


if __name__ == "__main__":
    driver = undetected_chromedriver.Chrome()# options=chrome_options добавить если вы хотите безголовый запуск
    open_ex()
    