from msilib.schema import Error
from posixpath import split
import pandas as pd
import numpy as np
df = pd.read_excel('Авангард.xlsx')
num_rows = 163
def categoryes():


    
    
    print(num_rows)
    i = 3
    while i<num_rows:
      name = df['Unnamed: 4'].iloc[i]
      price = df['Unnamed: 13'].iloc[i]

       

      
      
      
      print(name)

      print(price)
      i = i+1
    



  








categoryes('Авангард.xlsx')